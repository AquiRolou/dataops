# Importando as bibliotecas que vamos utilizar
from airflow import DAG
from airflow.operators.bash_operator import BashOperator
from datetime import datetime, timedelta

# definição de argumentos básicos
default_args = {
    "owner": "9ABD",
    "depends_on_past": False,
    "start_date": datetime(2015, 6, 1),
    "email": ["airflow@airflow.com"],
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    # 'queue': 'bash_queue',
    # 'pool': 'backfill',
    # 'priority_weight': 10,
    # 'end_date': datetime(2016, 1, 1),
}
# Nomeando a DAG e definindo quando ela vai ser executada (você pode usar argumentos em Crontab também caso queira que a DAG execute por exemplo todos os dias as 8 da manhã)
dag = DAG(
   'Job-DataScience-AQUI-RODOU',
   schedule_interval=timedelta(minutes=1),
   catchup=False,
   default_args=default_args
   )
# Definindo as tarefas que a DAG vai executar, nesse caso a execução de dois programas Python, chamando sua execução por comandos bash
# O operador Bash, também pode ser utilizado para executar jobs Talend via Sh
t1 = BashOperator(
   dag=dag,
   task_id='job_datascience-v0.1',
   bash_command="""
   cd /d/docker-airflow/dags/etl-scripts/Job-DataScience
   job_dataScience_02_run.sh
   """)
t2 = BashOperator(
  dag=dag,
  task_id='job_vendas-v0.1',
  bash_command="""
  cd /d/docker-airflow/dags/etl-scripts/Job-Vendas
  Vendas_run.sh
  """)
# Definindo o padrão de execução, nesse caso executamos t1 e depois t2
t1 >> t2 
